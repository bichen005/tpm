"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import type { Device } from "@/lib/types"

interface DepartmentStatsCardProps {
  department: string
  devices: Device[]
  onFilterChange: (department: string, category?: string) => void
  activeFilters: {
    department: string
    category: string
  }
}

export default function DepartmentStatsCard({
  department,
  devices,
  onFilterChange,
  activeFilters,
}: DepartmentStatsCardProps) {
  // 过滤该部门的设备
  const departmentDevices = devices.filter((device) => device.department === department)

  // 计算各分类的设备数量
  const getCategoryCount = (category: string) => {
    return departmentDevices.filter((device) => device.category === category).length
  }

  // 获取该部门所有设备分类
  const getCategories = () => {
    const departmentCategories: Record<string, string[]> = {
      管子分厂: ["焊接设备", "生产线", "起重设备", "弯管机", "机加设备", "切割设备", "热处理设备"],
      集箱分厂: ["焊接设备", "起重设备", "机加设备", "切割设备", "热处理设备", "生产线"],
      核容分厂: ["焊接设备", "起重设备", "卷板机", "机加设备", "切割设备", "热处理设备"],
    }

    return departmentCategories[department] || []
  }

  // 处理点击事件
  const handleClick = (category?: string) => {
    onFilterChange(department, category)
  }

  // 判断是否激活
  const isActive = (category?: string) => {
    if (category) {
      return activeFilters.department === department && activeFilters.category === category
    }
    return activeFilters.department === department && activeFilters.category === ""
  }

  return (
    <Card
      className={cn("border-l-4", isActive() && !activeFilters.category ? "border-l-theme-700" : "border-l-gray-200")}
    >
      <CardHeader className="pb-2 bg-gray-50 border-b">
        <CardTitle className="flex justify-between items-center">
          <span className="text-xl font-bold text-theme-700">{department}</span>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleClick()}
            className={cn(
              "text-base font-semibold hover:bg-theme-100",
              isActive() && !activeFilters.category ? "bg-theme-100 text-theme-700 font-bold" : "",
            )}
          >
            设备总数: {departmentDevices.length}
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-2">
          {getCategories().map((category) => {
            const count = getCategoryCount(category)
            return (
              <Button
                key={category}
                variant="outline"
                size="sm"
                onClick={() => handleClick(category)}
                className={cn(
                  "justify-start text-sm font-medium h-auto py-2 px-3 w-auto inline-flex whitespace-nowrap",
                  isActive(category) ? "border-theme-700 bg-theme-50 text-theme-700 font-semibold" : "",
                )}
              >
                <span>
                  {category}({count})
                </span>
              </Button>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
