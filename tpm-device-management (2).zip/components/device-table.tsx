"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Edit, Eye, MoreHorizontal, Trash2 } from "lucide-react"
import { useRouter } from "next/navigation"
import type { Device } from "@/lib/types"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

interface DeviceTableProps {
  devices: Device[]
}

export default function DeviceTable({ devices }: DeviceTableProps) {
  const router = useRouter()
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [deviceToDelete, setDeviceToDelete] = useState<string | null>(null)

  const handleEdit = (id: string, mode: "edit" | "view" = "edit") => {
    router.push(`/devices/${id}${mode === "view" ? "?mode=view" : ""}`)
  }

  const handleDelete = (id: string) => {
    setDeviceToDelete(id)
    setDeleteDialogOpen(true)
  }

  const confirmDelete = () => {
    // 在实际应用中，这里会调用API删除设备
    console.log(`删除设备: ${deviceToDelete}`)
    setDeleteDialogOpen(false)
    setDeviceToDelete(null)
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "正常":
        return <Badge className="bg-green-500">正常</Badge>
      case "维修中":
        return <Badge className="bg-yellow-500">维修中</Badge>
      case "停用":
        return <Badge className="bg-red-500">停用</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  return (
    <>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow className="bg-theme-50">
              <TableHead>设备名称</TableHead>
              <TableHead>设备分类</TableHead>
              <TableHead>固定资产编号</TableHead>
              <TableHead>型号/规格</TableHead>
              <TableHead>使用单位</TableHead>
              <TableHead>责任人</TableHead>
              <TableHead>状态</TableHead>
              <TableHead className="text-right">操作</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {devices.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-6 text-gray-500">
                  没有找到符合条件的设备
                </TableCell>
              </TableRow>
            ) : (
              devices.map((device) => (
                <TableRow key={device.id} className="hover:bg-theme-50">
                  <TableCell className="font-medium">{device.name}</TableCell>
                  <TableCell>{device.category}</TableCell>
                  <TableCell>{device.assetNumber}</TableCell>
                  <TableCell>{device.model}</TableCell>
                  <TableCell>{device.department}</TableCell>
                  <TableCell>{device.responsiblePerson}</TableCell>
                  <TableCell>{getStatusBadge(device.status)}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="hover:bg-theme-100">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">操作菜单</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleEdit(device.id, "view")}>
                          <Eye className="mr-2 h-4 w-4" />
                          详情
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleEdit(device.id)}>
                          <Edit className="mr-2 h-4 w-4" />
                          编辑
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600" onClick={() => handleDelete(device.id)}>
                          <Trash2 className="mr-2 h-4 w-4" />
                          删除
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription>您确定要删除这个设备吗？此操作无法撤销。</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-theme-700 hover:bg-theme-800">
              删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
