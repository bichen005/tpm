"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Activity, ChevronDown, ChevronRight, Database, Settings } from "lucide-react"
import { useState } from "react"

export default function Sidebar() {
  const pathname = usePathname()
  const [statusMenuOpen, setStatusMenuOpen] = useState(true)

  // 主菜单项
  const mainRoutes = [
    {
      label: "设备管理",
      icon: Database,
      href: "/devices",
      active: pathname === "/devices" || pathname.startsWith("/devices/"),
    },
  ]

  // 设备状态子菜单项
  const statusSubRoutes = [
    {
      label: "状态地图",
      href: "/status/map",
      active: pathname === "/status/map",
    },
    {
      label: "运行分析",
      href: "/status",
      active: pathname === "/status",
    },
  ]

  // 其他菜单项
  const otherRoutes = [
    {
      label: "系统设置",
      icon: Settings,
      href: "/settings",
      active: pathname === "/settings",
    },
  ]

  // 检查状态菜单是否应该展开
  const isStatusActive = statusSubRoutes.some((route) => route.active)

  return (
    <div className="flex h-full w-64 flex-col border-r bg-white">
      <div className="flex h-14 items-center border-b px-6">
        <h1 className="text-lg font-bold text-theme-700">TPM设备管理系统</h1>
      </div>
      <div className="flex-1 overflow-auto py-2">
        <nav className="grid gap-1 px-2">
          {/* 主菜单项 */}
          {mainRoutes.map((route) => (
            <Link
              key={route.href}
              href={route.href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium",
                route.active ? "bg-theme-100 text-theme-700" : "text-gray-600 hover:bg-gray-100 hover:text-theme-700",
              )}
            >
              <route.icon className="h-5 w-5" />
              {route.label}
            </Link>
          ))}

          {/* 设备状态菜单（可展开） */}
          <div className="space-y-1">
            <button
              onClick={() => setStatusMenuOpen(!statusMenuOpen)}
              className={cn(
                "flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm font-medium",
                isStatusActive ? "bg-theme-100 text-theme-700" : "text-gray-600 hover:bg-gray-100 hover:text-theme-700",
              )}
            >
              <div className="flex items-center gap-3">
                <Activity className="h-5 w-5" />
                <span>设备状态</span>
              </div>
              {statusMenuOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            </button>

            {/* 子菜单 */}
            {statusMenuOpen && (
              <div className="pl-10 space-y-1">
                {statusSubRoutes.map((route) => (
                  <Link
                    key={route.href}
                    href={route.href}
                    className={cn(
                      "flex items-center rounded-lg px-3 py-2 text-sm font-medium",
                      route.active
                        ? "bg-theme-50 text-theme-700"
                        : "text-gray-600 hover:bg-gray-100 hover:text-theme-700",
                    )}
                  >
                    {route.label}
                  </Link>
                ))}
              </div>
            )}
          </div>

          {/* 其他菜单项 */}
          {otherRoutes.map((route) => (
            <Link
              key={route.href}
              href={route.href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium",
                route.active ? "bg-theme-100 text-theme-700" : "text-gray-600 hover:bg-gray-100 hover:text-theme-700",
              )}
            >
              <route.icon className="h-5 w-5" />
              {route.label}
            </Link>
          ))}
        </nav>
      </div>
    </div>
  )
}
