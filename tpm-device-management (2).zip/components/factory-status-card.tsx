"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { useEffect, useState } from "react"

interface CoreStat {
  label: string
  value: string
}

interface FactoryStatusCardProps {
  title: string
  devices: any[]
  collectionRate: string
  coreStats: CoreStat[]
  refreshTime?: Date
}

export default function FactoryStatusCard({
  title,
  devices,
  collectionRate,
  coreStats,
  refreshTime,
}: FactoryStatusCardProps) {
  // 模拟设备运行状态
  const [runningCount, setRunningCount] = useState(Math.floor(devices.length * 0.6))
  const [standbyCount, setStandbyCount] = useState(Math.floor(devices.length * 0.3))
  const [offCount, setOffCount] = useState(Math.floor(devices.length * 0.1))
  const [blinkState, setBlinkState] = useState(true)

  // 闪烁效果
  useEffect(() => {
    const interval = setInterval(() => {
      setBlinkState((prev) => !prev)
    }, 1000)
    return () => clearInterval(interval)
  }, [])

  // 当refreshTime变化时，重新生成随机数据
  useEffect(() => {
    if (refreshTime) {
      // 在实际应用中，这里应该从API获取最新数据
      // 这里使用随机数据模拟数据变化
      const total = devices.length
      const running = Math.floor(total * (0.5 + Math.random() * 0.2))
      const standby = Math.floor((total - running) * (0.6 + Math.random() * 0.3))
      const off = total - running - standby

      setRunningCount(running)
      setStandbyCount(standby)
      setOffCount(off)
    }
  }, [refreshTime, devices.length])

  return (
    <Card className="border-theme-200">
      <CardHeader className="bg-theme-50 py-2 px-4 flex flex-row justify-between items-center">
        <CardTitle className="text-theme-700 text-base font-bold">{title}</CardTitle>
        <div className="flex items-center">
          <span className="text-xs font-medium text-gray-600 mr-1">采集率:</span>
          <span className="text-sm font-bold text-theme-700">{collectionRate}</span>
        </div>
      </CardHeader>
      <CardContent className="p-3">
        <div className="space-y-2">
          {/* 设备运行状态 */}
          <div className="grid grid-cols-3 gap-2">
            <StatusItem label="运行" count={runningCount} color="green" blink={blinkState} />
            <StatusItem label="待机" count={standbyCount} color="yellow" blink={false} />
            <StatusItem label="关机" count={offCount} color="gray" blink={false} />
          </div>

          {/* 运行统计 */}
          <div className="space-y-1.5 pt-1">
            <h4 className="text-xs font-semibold text-gray-700 border-b border-gray-100 pb-1">运行统计</h4>
            <div className="grid grid-cols-2 gap-x-2 gap-y-1.5">
              {coreStats.map((stat, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-xs font-medium text-gray-700">{stat.label}</span>
                  <span className="text-sm font-bold text-theme-700">{stat.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

interface StatusItemProps {
  label: string
  count: number
  color: "green" | "yellow" | "gray"
  blink: boolean
}

function StatusItem({ label, count, color, blink }: StatusItemProps) {
  const getStatusColor = () => {
    switch (color) {
      case "green":
        return blink ? "bg-green-500 shadow-lg shadow-green-200" : "bg-green-400"
      case "yellow":
        return "bg-yellow-400 shadow-sm shadow-yellow-200"
      case "gray":
        return "bg-gray-400"
      default:
        return "bg-gray-400"
    }
  }

  const getTextColor = () => {
    switch (color) {
      case "green":
        return "text-green-600"
      case "yellow":
        return "text-yellow-600"
      case "gray":
        return "text-gray-600"
      default:
        return "text-gray-600"
    }
  }

  return (
    <div className="flex flex-col items-center">
      <div className={cn("w-3.5 h-3.5 rounded-full mb-1 transition-all duration-300", getStatusColor())} />
      <span className={cn("text-xs font-medium", getTextColor())}>{label}</span>
      <span className="text-base font-bold">{count}</span>
    </div>
  )
}
