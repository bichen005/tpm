"use client"

import { useRouter } from "next/navigation"
import { useState, useEffect } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Eye, ArrowUpDown, ChevronLeft, ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Device } from "@/lib/types"

// 扩展设备类型，添加运行时长和当前使用人
interface DeviceWithRunningInfo extends Device {
  runningHoursLast15Days: number
  currentUser: string
  runningStatus: "running" | "standby" | "off"
}

interface DeviceRunningStatusListProps {
  devices: Device[]
  runningHoursRange?: [number, number]
  runningStatusFilter?: string
  userFilter?: string
}

// 运行状态指示器组件
function RunningStatusIndicator({ status }: { status: "running" | "standby" | "off" }) {
  const [blink, setBlink] = useState(true)

  // 只有运行状态需要闪烁效果
  useEffect(() => {
    if (status === "running") {
      const interval = setInterval(() => {
        setBlink((prev) => !prev)
      }, 1000)
      return () => clearInterval(interval)
    }
  }, [status])

  const getStatusColor = () => {
    switch (status) {
      case "running":
        return blink ? "bg-green-500 shadow-sm shadow-green-200" : "bg-green-400"
      case "standby":
        return "bg-yellow-400"
      case "off":
        return "bg-gray-400"
      default:
        return "bg-gray-400"
    }
  }

  const getStatusText = () => {
    switch (status) {
      case "running":
        return "运行"
      case "standby":
        return "待机"
      case "off":
        return "关机"
      default:
        return "未知"
    }
  }

  return (
    <div className="flex items-center">
      <div
        className={cn("w-3 h-3 rounded-full mr-2 transition-all duration-300", getStatusColor())}
        aria-hidden="true"
      />
      <span>{getStatusText()}</span>
    </div>
  )
}

export default function DeviceRunningStatusList({
  devices,
  runningHoursRange = [0, 360],
  runningStatusFilter = "",
  userFilter = "",
}: DeviceRunningStatusListProps) {
  const router = useRouter()
  const [sortDirection, setSortDirection] = useState<"asc" | "desc" | null>(null)
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10

  // 重置页码当筛选条件变化时
  useEffect(() => {
    setCurrentPage(1)
  }, [runningHoursRange, runningStatusFilter, userFilter])

  // 为设备添加模拟的运行时长、当前使用人和运行状态数据
  const devicesWithRunningInfo: DeviceWithRunningInfo[] = devices.map((device) => {
    // 生成15天内的随机运行时长，范围在0-360小时之间，精确到小数点后1位
    const runningHours = Number.parseFloat((Math.random() * 360).toFixed(1))

    // 为每个设备分配一个模拟的当前使用人
    const users = ["张三", "李四", "王五", "赵六", "钱七", "孙八", "周九", "吴十"]
    const currentUser = users[Math.floor(Math.random() * users.length)]

    // 随机分配运行状态
    const statuses: Array<"running" | "standby" | "off"> = ["running", "standby", "off"]
    const runningStatus = statuses[Math.floor(Math.random() * statuses.length)]

    return {
      ...device,
      runningHoursLast15Days: runningHours,
      currentUser,
      runningStatus,
    }
  })

  // 应用高级筛选
  const filteredDevices = devicesWithRunningInfo.filter((device) => {
    // 筛选运行时长
    const matchesRunningHours =
      device.runningHoursLast15Days >= runningHoursRange[0] && device.runningHoursLast15Days <= runningHoursRange[1]

    // 筛选运行状态
    const matchesRunningStatus = runningStatusFilter === "" || device.runningStatus === runningStatusFilter

    // 筛选使用人
    const matchesUser = userFilter === "" || device.currentUser.includes(userFilter)

    return matchesRunningHours && matchesRunningStatus && matchesUser
  })

  // 处理排序
  const handleSort = () => {
    if (sortDirection === null) {
      setSortDirection("desc") // 首次点击，按降序排序（时间长的在前）
    } else if (sortDirection === "desc") {
      setSortDirection("asc") // 再次点击，切换为升序
    } else {
      setSortDirection(null) // 第三次点击，取消排序
    }
  }

  // 排序设备列表
  const sortedDevices = [...filteredDevices]
  if (sortDirection === "asc") {
    sortedDevices.sort((a, b) => a.runningHoursLast15Days - b.runningHoursLast15Days)
  } else if (sortDirection === "desc") {
    sortedDevices.sort((a, b) => b.runningHoursLast15Days - a.runningHoursLast15Days)
  }

  // 处理分页
  const totalPages = Math.ceil(sortedDevices.length / itemsPerPage)
  const paginatedDevices = sortedDevices.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  // 处理查看详情
  const handleViewDetails = (deviceId: string) => {
    router.push(`/status/device/${deviceId}`)
  }

  return (
    <div className="space-y-4">
      <div className="rounded-md border border-theme-200">
        <Table>
          <TableHeader>
            <TableRow className="bg-theme-50">
              <TableHead>设备名称</TableHead>
              <TableHead>设备分类</TableHead>
              <TableHead>固定资产编号</TableHead>
              <TableHead>使用单位</TableHead>
              <TableHead>型号/规格</TableHead>
              <TableHead>
                <div className="flex items-center cursor-pointer" onClick={handleSort}>
                  近15日运行时长(h)
                  <ArrowUpDown
                    className={cn("ml-1 h-4 w-4", {
                      "text-theme-700": sortDirection !== null,
                      "text-gray-400": sortDirection === null,
                    })}
                  />
                </div>
              </TableHead>
              <TableHead>当前运行状态</TableHead>
              <TableHead>当前使用人</TableHead>
              <TableHead className="text-right">操作</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedDevices.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} className="text-center py-6 text-gray-500">
                  没有找到符合条件的设备
                </TableCell>
              </TableRow>
            ) : (
              paginatedDevices.map((device) => (
                <TableRow key={device.id} className="hover:bg-theme-50">
                  <TableCell className="font-medium">{device.name}</TableCell>
                  <TableCell>{device.category}</TableCell>
                  <TableCell>{device.assetNumber}</TableCell>
                  <TableCell>{device.department}</TableCell>
                  <TableCell>{device.model}</TableCell>
                  <TableCell>{device.runningHoursLast15Days}</TableCell>
                  <TableCell>
                    <RunningStatusIndicator status={device.runningStatus} />
                  </TableCell>
                  <TableCell>{device.currentUser}</TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleViewDetails(device.id)}
                      className="border-theme-200 hover:bg-theme-100"
                    >
                      <Eye className="mr-2 h-4 w-4" />
                      详情
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* 分页控件 */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-500">
            显示 {sortedDevices.length} 条结果中的 {(currentPage - 1) * itemsPerPage + 1} -{" "}
            {Math.min(currentPage * itemsPerPage, sortedDevices.length)} 条
          </div>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="border-theme-200 hover:bg-theme-50"
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              上一页
            </Button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
              <Button
                key={page}
                variant={page === currentPage ? "default" : "outline"}
                size="sm"
                onClick={() => setCurrentPage(page)}
                className={
                  page === currentPage ? "bg-theme-700 hover:bg-theme-800" : "border-theme-200 hover:bg-theme-50"
                }
              >
                {page}
              </Button>
            ))}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="border-theme-200 hover:bg-theme-50"
            >
              下一页
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
