"use client"

import { cn } from "@/lib/utils"

interface DeviceStatusCardProps {
  name: string
  status: {
    running: number
    standby: number
    off: number
  }
  blinkState: boolean
}

export default function DeviceStatusCard({ name, status, blinkState }: DeviceStatusCardProps) {
  return (
    <div className="bg-white/90 backdrop-blur-sm border border-gray-200 rounded-md shadow-md p-2 w-[120px] text-center transform hover:scale-105 transition-transform z-10">
      <h4 className="text-xs font-bold text-theme-700 truncate mb-1" title={name}>
        {name}
      </h4>
      <div className="flex justify-around items-center">
        <StatusIndicator label="运行" count={status.running} color="green" blink={blinkState} />
        <StatusIndicator label="待机" count={status.standby} color="yellow" blink={false} />
        <StatusIndicator label="关机" count={status.off} color="gray" blink={false} />
      </div>
    </div>
  )
}

interface StatusIndicatorProps {
  label: string
  count: number
  color: "green" | "yellow" | "gray"
  blink: boolean
}

function StatusIndicator({ label, count, color, blink }: StatusIndicatorProps) {
  const getStatusColor = () => {
    switch (color) {
      case "green":
        return blink ? "bg-green-500 shadow-sm shadow-green-200" : "bg-green-400"
      case "yellow":
        return "bg-yellow-400"
      case "gray":
        return "bg-gray-400"
      default:
        return "bg-gray-400"
    }
  }

  return (
    <div className="flex flex-col items-center">
      <div className={cn("w-2.5 h-2.5 rounded-full mb-0.5 transition-all duration-300", getStatusColor())} />
      <span className="text-[10px] text-gray-600">{count}</span>
    </div>
  )
}
