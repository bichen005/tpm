import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import type { Device } from "@/lib/types"

interface StatusTableProps {
  devices: Device[]
}

export default function StatusTable({ devices }: StatusTableProps) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "正常":
        return <Badge className="bg-green-500">正常</Badge>
      case "维修中":
        return <Badge className="bg-yellow-500">维修中</Badge>
      case "停用":
        return <Badge className="bg-red-500">停用</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  return (
    <div className="rounded-md border border-theme-200">
      <Table>
        <TableHeader>
          <TableRow className="bg-theme-50">
            <TableHead>设备名称</TableHead>
            <TableHead>设备分类</TableHead>
            <TableHead>使用单位</TableHead>
            <TableHead>责任人</TableHead>
            <TableHead>状态</TableHead>
            <TableHead>上次检修日期</TableHead>
            <TableHead>下次检修日期</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {devices.length === 0 ? (
            <TableRow>
              <TableCell colSpan={7} className="text-center py-6 text-gray-500">
                没有找到符合条件的设备
              </TableCell>
            </TableRow>
          ) : (
            devices.map((device) => (
              <TableRow key={device.id} className="hover:bg-theme-50">
                <TableCell className="font-medium">{device.name}</TableCell>
                <TableCell>{device.category}</TableCell>
                <TableCell>{device.department}</TableCell>
                <TableCell>{device.responsiblePerson}</TableCell>
                <TableCell>{getStatusBadge(device.status)}</TableCell>
                <TableCell>2023-12-15</TableCell>
                <TableCell>2024-06-15</TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  )
}
