"use client"

import { useState } from "react"
import { Check, ChevronsUpDown, X } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Badge } from "@/components/ui/badge"
import { deviceData } from "@/lib/data"

interface DeviceSelectorProps {
  excludeIds?: string[]
  onSelect: (values: string[]) => void
  selectedValues: string[]
}

export default function DeviceSelector({ excludeIds = [], onSelect, selectedValues }: DeviceSelectorProps) {
  const [open, setOpen] = useState(false)
  const [searchValue, setSearchValue] = useState("")

  // 过滤掉已排除的设备
  const availableDevices = deviceData.filter((device) => !excludeIds.includes(device.id))

  // 根据搜索值过滤设备
  const filteredDevices = availableDevices.filter(
    (device) =>
      device.name.toLowerCase().includes(searchValue.toLowerCase()) ||
      device.assetNumber.toLowerCase().includes(searchValue.toLowerCase()) ||
      device.category.toLowerCase().includes(searchValue.toLowerCase()),
  )

  // 获取已选设备的详细信息
  const selectedDevices = selectedValues.map((id) => deviceData.find((device) => device.id === id)).filter(Boolean)

  // 处理选择设备
  const handleSelect = (deviceId: string) => {
    if (selectedValues.includes(deviceId)) {
      onSelect(selectedValues.filter((id) => id !== deviceId))
    } else {
      onSelect([...selectedValues, deviceId])
    }
  }

  // 移除已选设备
  const handleRemove = (deviceId: string) => {
    onSelect(selectedValues.filter((id) => id !== deviceId))
  }

  return (
    <div className="space-y-2">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="w-full justify-between border-theme-200 focus:ring-theme-500"
          >
            {selectedValues.length > 0 ? `已选择 ${selectedValues.length} 个设备` : "搜索选择设备"}
            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-full p-0">
          <Command>
            <CommandInput placeholder="搜索设备名称、编号或分类..." onValueChange={setSearchValue} />
            <CommandList>
              <CommandEmpty>未找到匹配的设备</CommandEmpty>
              <CommandGroup className="max-h-60 overflow-auto">
                {filteredDevices.map((device) => (
                  <CommandItem key={device.id} value={device.id} onSelect={() => handleSelect(device.id)}>
                    <Check
                      className={cn("mr-2 h-4 w-4", selectedValues.includes(device.id) ? "opacity-100" : "opacity-0")}
                    />
                    <div className="flex flex-col">
                      <span>{device.name}</span>
                      <span className="text-xs text-gray-500">
                        {device.assetNumber} | {device.category}
                      </span>
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>

      {selectedDevices.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-2">
          {selectedDevices.map(
            (device) =>
              device && (
                <Badge key={device.id} variant="secondary" className="flex items-center gap-1 bg-theme-100">
                  {device.name}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-4 w-4 p-0 hover:bg-theme-200"
                    onClick={() => handleRemove(device.id)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </Badge>
              ),
          )}
        </div>
      )}
    </div>
  )
}
