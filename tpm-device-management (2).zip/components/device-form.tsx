"use client"

import type { Device } from "@/lib/types"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DatePicker } from "@/components/date-picker"

interface DeviceFormProps {
  device: Device
  onChange: (device: Device) => void
  fields: (keyof Device)[]
  readOnly?: boolean
}

export default function DeviceForm({ device, onChange, fields, readOnly = false }: DeviceFormProps) {
  const handleChange = (field: keyof Device, value: string) => {
    onChange({ ...device, [field]: value })
  }

  const renderField = (field: keyof Device) => {
    const fieldLabels: Record<keyof Device, string> = {
      id: "ID",
      name: "设备名称",
      category: "设备分类",
      assetNumber: "固定资产编号",
      model: "型号/规格",
      totalPower: "总功率",
      department: "使用单位",
      responsiblePerson: "责任人",
      status: "状态",
      manufacturer: "生产厂家",
      serialNumber: "出厂编号",
      productionDate: "出厂日期",
      acceptanceDate: "竣工验收日期",
      installationLocation: "安装地点",
      deviceGrade: "设备分级",
    }

    switch (field) {
      case "category":
        return (
          <div className="grid gap-2">
            <Label htmlFor={field}>{fieldLabels[field]}</Label>
            <Select value={device[field]} onValueChange={(value) => handleChange(field, value)}>
              <SelectTrigger id={field} className="border-theme-200 focus:ring-theme-500" disabled={readOnly}>
                <SelectValue placeholder={`选择${fieldLabels[field]}`} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="焊接设备">焊接设备</SelectItem>
                <SelectItem value="起重设备">起重设备</SelectItem>
                <SelectItem value="机加设备">机加设备</SelectItem>
                <SelectItem value="切割设备">切割设备</SelectItem>
                <SelectItem value="热处理设备">热处理设备</SelectItem>
                <SelectItem value="弯管机">弯管机</SelectItem>
                <SelectItem value="卷板机">卷板机</SelectItem>
                <SelectItem value="生产线">生产线</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )
      case "department":
        return (
          <div className="grid gap-2">
            <Label htmlFor={field}>{fieldLabels[field]}</Label>
            <Select value={device[field]} onValueChange={(value) => handleChange(field, value)}>
              <SelectTrigger id={field} className="border-theme-200 focus:ring-theme-500" disabled={readOnly}>
                <SelectValue placeholder={`选择${fieldLabels[field]}`} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="管子分厂">管子分厂</SelectItem>
                <SelectItem value="集箱分厂">集箱分厂</SelectItem>
                <SelectItem value="核容分厂">核容分厂</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )
      case "status":
        return (
          <div className="grid gap-2">
            <Label htmlFor={field}>{fieldLabels[field]}</Label>
            <Select value={device[field]} onValueChange={(value) => handleChange(field, value)}>
              <SelectTrigger id={field} className="border-theme-200 focus:ring-theme-500" disabled={readOnly}>
                <SelectValue placeholder={`选择${fieldLabels[field]}`} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="正常">正常</SelectItem>
                <SelectItem value="维修中">维修中</SelectItem>
                <SelectItem value="停用">停用</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )
      case "deviceGrade":
        return (
          <div className="grid gap-2">
            <Label htmlFor={field}>{fieldLabels[field]}</Label>
            <Select value={device[field]} onValueChange={(value) => handleChange(field, value)}>
              <SelectTrigger id={field} className="border-theme-200 focus:ring-theme-500" disabled={readOnly}>
                <SelectValue placeholder={`选择${fieldLabels[field]}`} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="A级">A级</SelectItem>
                <SelectItem value="B级">B级</SelectItem>
                <SelectItem value="C级">C级</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )
      case "productionDate":
      case "acceptanceDate":
        return (
          <div className="grid gap-2">
            <Label htmlFor={field}>{fieldLabels[field]}</Label>
            <DatePicker
              value={device[field] ? new Date(device[field]) : undefined}
              onChange={(date) => handleChange(field, date ? date.toISOString().split("T")[0] : "")}
              readOnly={readOnly}
            />
          </div>
        )
      default:
        return (
          <div className="grid gap-2">
            <Label htmlFor={field}>{fieldLabels[field]}</Label>
            <Input
              id={field}
              value={device[field]}
              onChange={(e) => handleChange(field, e.target.value)}
              placeholder={`输入${fieldLabels[field]}`}
              className="border-theme-200 focus-visible:ring-theme-500"
              readOnly={readOnly}
            />
          </div>
        )
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {fields.map((field) => (
        <div key={field}>{renderField(field)}</div>
      ))}
    </div>
  )
}
