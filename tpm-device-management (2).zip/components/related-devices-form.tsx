"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Trash2, Plus } from "lucide-react"
import { deviceData } from "@/lib/data"
import type { Device, RelationType } from "@/lib/types"
import DeviceSelector from "@/components/device-selector"

interface RelatedDevicesFormProps {
  device: Device
  onChange: (device: Device) => void
  readOnly?: boolean
}

export default function RelatedDevicesForm({ device, onChange, readOnly = false }: RelatedDevicesFormProps) {
  const [selectedDevices, setSelectedDevices] = useState<string[]>([])
  const [relationType, setRelationType] = useState<RelationType>("配套设备")
  const [isAdding, setIsAdding] = useState(false)

  // 获取已关联设备的详细信息
  const relatedDevicesDetails = device.relatedDevices
    ? device.relatedDevices.map((rd) => {
        const relatedDevice = deviceData.find((d) => d.id === rd.deviceId)
        return {
          ...rd,
          deviceDetails: relatedDevice,
        }
      })
    : []

  // 添加关联设备
  const handleAddRelatedDevices = () => {
    if (selectedDevices.length === 0) return

    const newRelatedDevices = [
      ...(device.relatedDevices || []),
      ...selectedDevices.map((deviceId) => ({
        deviceId,
        relationType,
      })),
    ]

    // 去重
    const uniqueRelatedDevices = newRelatedDevices.filter(
      (rd, index, self) => index === self.findIndex((t) => t.deviceId === rd.deviceId),
    )

    onChange({
      ...device,
      relatedDevices: uniqueRelatedDevices,
    })

    // 重置选择状态
    setSelectedDevices([])
    setIsAdding(false)
  }

  // 删除关联设备
  const handleRemoveRelatedDevice = (deviceId: string) => {
    const newRelatedDevices = device.relatedDevices
      ? device.relatedDevices.filter((rd) => rd.deviceId !== deviceId)
      : []

    onChange({
      ...device,
      relatedDevices: newRelatedDevices,
    })
  }

  // 获取设备状态徽章
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "正常":
        return <Badge className="bg-green-500">正常</Badge>
      case "维修中":
        return <Badge className="bg-yellow-500">维修中</Badge>
      case "停用":
        return <Badge className="bg-red-500">停用</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      {!readOnly && (
        <div className="flex justify-end">
          {!isAdding ? (
            <Button onClick={() => setIsAdding(true)} className="bg-theme-700 hover:bg-theme-800">
              <Plus className="mr-2 h-4 w-4" />
              添加关联设备
            </Button>
          ) : (
            <div className="w-full space-y-4">
              <Card>
                <CardContent className="p-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <DeviceSelector
                        excludeIds={[device.id, ...(device.relatedDevices?.map((rd) => rd.deviceId) || [])]}
                        onSelect={setSelectedDevices}
                        selectedValues={selectedDevices}
                      />
                    </div>
                    <div className="flex items-end gap-4">
                      <div className="flex-1">
                        <Select value={relationType} onValueChange={(value) => setRelationType(value as RelationType)}>
                          <SelectTrigger className="border-theme-200 focus:ring-theme-500">
                            <SelectValue placeholder="关联类型" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="配套设备">配套设备</SelectItem>
                            <SelectItem value="备用设备">备用设备</SelectItem>
                            <SelectItem value="替代设备">替代设备</SelectItem>
                            <SelectItem value="附属设备">附属设备</SelectItem>
                            <SelectItem value="上游设备">上游设备</SelectItem>
                            <SelectItem value="下游设备">下游设备</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          onClick={handleAddRelatedDevices}
                          disabled={selectedDevices.length === 0}
                          className="bg-theme-700 hover:bg-theme-800"
                        >
                          确认
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => {
                            setIsAdding(false)
                            setSelectedDevices([])
                          }}
                        >
                          取消
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      )}

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow className="bg-theme-50">
              <TableHead>设备名称</TableHead>
              <TableHead>设备分类</TableHead>
              <TableHead>固定资产编号</TableHead>
              <TableHead>使用单位</TableHead>
              <TableHead>状态</TableHead>
              <TableHead>关联类型</TableHead>
              {!readOnly && <TableHead className="text-right">操作</TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {relatedDevicesDetails.length === 0 ? (
              <TableRow>
                <TableCell colSpan={readOnly ? 6 : 7} className="text-center py-6 text-gray-500">
                  暂无关联设备
                </TableCell>
              </TableRow>
            ) : (
              relatedDevicesDetails.map((rd) => (
                <TableRow key={rd.deviceId} className="hover:bg-theme-50">
                  <TableCell className="font-medium">{rd.deviceDetails?.name || "未知设备"}</TableCell>
                  <TableCell>{rd.deviceDetails?.category || "-"}</TableCell>
                  <TableCell>{rd.deviceDetails?.assetNumber || "-"}</TableCell>
                  <TableCell>{rd.deviceDetails?.department || "-"}</TableCell>
                  <TableCell>{rd.deviceDetails ? getStatusBadge(rd.deviceDetails.status) : "-"}</TableCell>
                  <TableCell>{rd.relationType}</TableCell>
                  {!readOnly && (
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveRelatedDevice(rd.deviceId)}
                        className="hover:bg-red-100 hover:text-red-600"
                      >
                        <Trash2 className="h-4 w-4" />
                        <span className="sr-only">删除</span>
                      </Button>
                    </TableCell>
                  )}
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
