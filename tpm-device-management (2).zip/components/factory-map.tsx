"use client"

import { useEffect, useState } from "react"
import DeviceStatusCard from "@/components/device-status-card"

interface FactoryMapProps {
  type: "pipe" | "nuclear" | "box"
  devices: any[]
  equipmentList: string[]
  refreshTime?: Date
}

export default function FactoryMap({ type, devices, equipmentList, refreshTime }: FactoryMapProps) {
  const [blinkState, setBlinkState] = useState(true)
  const [equipmentStatus, setEquipmentStatus] = useState<
    Record<string, { running: number; standby: number; off: number }>
  >({})

  // 闪烁效果
  useEffect(() => {
    const interval = setInterval(() => {
      setBlinkState((prev) => !prev)
    }, 1000)
    return () => clearInterval(interval)
  }, [])

  // 当refreshTime变化时，重新生成设备状态数据
  useEffect(() => {
    const newStatus: Record<string, { running: number; standby: number; off: number }> = {}

    equipmentList.forEach((equipment) => {
      // 在实际应用中，这里应该根据真实数据计算
      newStatus[equipment] = {
        running: Math.floor(Math.random() * 5) + 1,
        standby: Math.floor(Math.random() * 3) + 1,
        off: Math.floor(Math.random() * 2),
      }
    })

    setEquipmentStatus(newStatus)
  }, [refreshTime, equipmentList])

  // 获取设备在地图上的位置
  const getEquipmentPosition = (equipment: string, index: number) => {
    // 管子分厂设备位置
    const pipeFactoryPositions = [
      { top: "18%", left: "22%" }, // CO2气体保护焊
      { top: "28%", left: "38%" }, // 氩弧焊机
      { top: "38%", left: "18%" }, // 直流焊机
      { top: "48%", left: "32%" }, // 交流电焊机
      { top: "58%", left: "22%" }, // 螺柱焊机
      { top: "15%", left: "65%" }, // 100米蛇形管自动线
      { top: "30%", left: "75%" }, // 70米蛇形管自动线
      { top: "45%", left: "65%" }, // 4头膜式壁生产线
      { top: "60%", left: "75%" }, // 8头膜式壁生产线
      { top: "75%", left: "65%" }, // 20头膜式壁生产线
      { top: "70%", left: "30%" }, // 液压弯管机
      { top: "25%", left: "55%" }, // 桥式行车
      { top: "65%", left: "50%" }, // 半龙门吊
    ]

    // 核容分厂设备位置
    const nuclearFactoryPositions = [
      { top: "20%", left: "25%" }, // 直流焊机
      { top: "40%", left: "20%" }, // 氩弧焊机
      { top: "60%", left: "30%" }, // CO2气体保护焊
      { top: "25%", left: "65%" }, // 马鞍埋弧焊机
      { top: "45%", left: "70%" }, // 环缝自动焊机
      { top: "65%", left: "65%" }, // 桥式行车
      { top: "70%", left: "20%" }, // 三辊卷板机
      { top: "35%", left: "45%" }, // 摇臂钻床
    ]

    // 集箱分厂设备位置
    const boxFactoryPositions = [
      { top: "20%", left: "30%" }, // CO2气体保护焊
      { top: "40%", left: "25%" }, // 氩弧焊机
      { top: "60%", left: "35%" }, // 直流焊机
      { top: "25%", left: "70%" }, // 螺柱焊机
      { top: "45%", left: "65%" }, // 窄间隙环缝焊工作站
      { top: "65%", left: "60%" }, // 桥式行车
      { top: "35%", left: "50%" }, // 半龙门吊
      { top: "70%", left: "45%" }, // 摇臂钻床
    ]

    // 根据工厂类型选择对应的位置数组
    const positionsMap = {
      pipe: pipeFactoryPositions,
      nuclear: nuclearFactoryPositions,
      box: boxFactoryPositions,
    }

    return positionsMap[type][index % positionsMap[type].length]
  }

  return (
    <div className="relative w-full h-full">
      {/* 工厂布局底图 */}
      {type === "pipe" && <PipeFactoryLayout />}
      {type === "nuclear" && <NuclearFactoryLayout />}
      {type === "box" && <BoxFactoryLayout />}

      {/* 设备状态卡片 */}
      {equipmentList.map((equipment, index) => {
        const position = getEquipmentPosition(equipment, index)
        const status = equipmentStatus[equipment] || { running: 0, standby: 0, off: 0 }

        return (
          <div
            key={index}
            className="absolute"
            style={{
              top: position.top,
              left: position.left,
            }}
          >
            <DeviceStatusCard name={equipment} status={status} blinkState={blinkState} />
          </div>
        )
      })}
    </div>
  )
}

// 管子分厂布局组件
function PipeFactoryLayout() {
  return (
    <div className="absolute inset-0 p-4">
      <svg width="100%" height="100%" viewBox="0 0 1000 600" className="border border-gray-200 rounded-md bg-gray-50">
        {/* 厂房外墙 */}
        <rect x="50" y="50" width="900" height="500" fill="#f8fafc" stroke="#94a3b8" strokeWidth="3" />

        {/* 主要区域分隔 */}
        <line x1="500" y1="50" x2="500" y2="550" stroke="#cbd5e1" strokeWidth="2" strokeDasharray="5,5" />
        <line x1="50" y1="300" x2="950" y2="300" stroke="#cbd5e1" strokeWidth="2" strokeDasharray="5,5" />

        {/* 左上区域 - 焊接区 */}
        <rect x="100" y="100" width="350" height="150" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" rx="5" />
        <text x="275" y="130" textAnchor="middle" fill="#334155" fontSize="16" fontWeight="bold">
          焊接区
        </text>

        {/* 右上区域 - 蛇形管生产区 */}
        <rect x="550" y="100" width="350" height="150" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" rx="5" />
        <text x="725" y="130" textAnchor="middle" fill="#334155" fontSize="16" fontWeight="bold">
          蛇形管生产区
        </text>

        {/* 左下区域 - 弯管区 */}
        <rect x="100" y="350" width="350" height="150" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" rx="5" />
        <text x="275" y="380" textAnchor="middle" fill="#334155" fontSize="16" fontWeight="bold">
          弯管区
        </text>

        {/* 右下区域 - 膜式壁生产区 */}
        <rect x="550" y="350" width="350" height="150" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" rx="5" />
        <text x="725" y="380" textAnchor="middle" fill="#334155" fontSize="16" fontWeight="bold">
          膜式壁生产区
        </text>

        {/* 通道 */}
        <rect x="50" y="275" width="900" height="50" fill="#f1f5f9" stroke="#94a3b8" strokeWidth="1" />
        <rect x="475" y="50" width="50" height="500" fill="#f1f5f9" stroke="#94a3b8" strokeWidth="1" />

        {/* 设备示意 - 焊接区 */}
        <rect x="120" y="150" width="60" height="30" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="1" rx="2" />
        <rect x="200" y="150" width="60" height="30" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="1" rx="2" />
        <rect x="280" y="150" width="60" height="30" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="1" rx="2" />
        <rect x="360" y="150" width="60" height="30" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="1" rx="2" />
        <rect x="120" y="200" width="60" height="30" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="1" rx="2" />

        {/* 设备示意 - 蛇形管生产区 */}
        <rect x="570" y="140" width="120" height="40" fill="#c7d2fe" stroke="#6366f1" strokeWidth="1" rx="2" />
        <rect x="720" y="140" width="120" height="40" fill="#c7d2fe" stroke="#6366f1" strokeWidth="1" rx="2" />
        <rect x="570" y="200" width="270" height="30" fill="#c7d2fe" stroke="#6366f1" strokeWidth="1" rx="2" />

        {/* 设备示意 - 弯管区 */}
        <rect x="150" y="400" width="80" height="40" fill="#ddd6fe" stroke="#8b5cf6" strokeWidth="1" rx="2" />
        <rect x="270" y="400" width="80" height="40" fill="#ddd6fe" stroke="#8b5cf6" strokeWidth="1" rx="2" />
        <rect x="150" y="460" width="200" height="20" fill="#ddd6fe" stroke="#8b5cf6" strokeWidth="1" rx="2" />

        {/* 设备示意 - 膜式壁生产区 */}
        <rect x="570" y="400" width="100" height="30" fill="#fae8ff" stroke="#d946ef" strokeWidth="1" rx="2" />
        <rect x="700" y="400" width="100" height="30" fill="#fae8ff" stroke="#d946ef" strokeWidth="1" rx="2" />
        <rect x="570" y="450" width="100" height="30" fill="#fae8ff" stroke="#d946ef" strokeWidth="1" rx="2" />
        <rect x="700" y="450" width="100" height="30" fill="#fae8ff" stroke="#d946ef" strokeWidth="1" rx="2" />

        {/* 起重设备 */}
        <line x1="275" y1="80" x2="275" y2="270" stroke="#475569" strokeWidth="3" />
        <line x1="725" y1="80" x2="725" y2="270" stroke="#475569" strokeWidth="3" />
        <line x1="275" y1="330" x2="275" y2="520" stroke="#475569" strokeWidth="3" />
        <line x1="725" y1="330" x2="725" y2="520" stroke="#475569" strokeWidth="3" />

        {/* 图例 */}
        <rect x="800" y="520" width="150" height="30" fill="none" stroke="#64748b" strokeWidth="1" rx="2" />
        <text x="875" y="540" textAnchor="middle" fill="#334155" fontSize="12">
          管子分厂设备布局
        </text>
      </svg>
    </div>
  )
}

// 核容分厂布局组件
function NuclearFactoryLayout() {
  return (
    <div className="absolute inset-0 p-4">
      <svg width="100%" height="100%" viewBox="0 0 1000 600" className="border border-gray-200 rounded-md bg-gray-50">
        {/* 厂房外墙 */}
        <rect x="50" y="50" width="900" height="500" fill="#f8fafc" stroke="#94a3b8" strokeWidth="3" />

        {/* 主要区域分隔 */}
        <line x1="500" y1="50" x2="500" y2="550" stroke="#cbd5e1" strokeWidth="2" strokeDasharray="5,5" />

        {/* 左侧区域 - 焊接区 */}
        <rect x="100" y="100" width="350" height="200" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" rx="5" />
        <text x="275" y="130" textAnchor="middle" fill="#334155" fontSize="16" fontWeight="bold">
          焊接区
        </text>

        {/* 右侧区域 - 机加工区 */}
        <rect x="550" y="100" width="350" height="200" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" rx="5" />
        <text x="725" y="130" textAnchor="middle" fill="#334155" fontSize="16" fontWeight="bold">
          机加工区
        </text>

        {/* 下方区域 - 卷板区 */}
        <rect x="100" y="350" width="800" height="150" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" rx="5" />
        <text x="500" y="380" textAnchor="middle" fill="#334155" fontSize="16" fontWeight="bold">
          卷板区
        </text>

        {/* 通道 */}
        <rect x="50" y="310" width="900" height="30" fill="#f1f5f9" stroke="#94a3b8" strokeWidth="1" />
        <rect x="475" y="50" width="50" height="500" fill="#f1f5f9" stroke="#94a3b8" strokeWidth="1" />

        {/* 设备示意 - 焊接区 */}
        <rect x="120" y="150" width="60" height="30" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="1" rx="2" />
        <rect x="200" y="150" width="60" height="30" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="1" rx="2" />
        <rect x="280" y="150" width="60" height="30" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="1" rx="2" />
        <rect x="120" y="200" width="60" height="30" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="1" rx="2" />
        <rect x="200" y="200" width="140" height="30" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="1" rx="2" />

        {/* 设备示意 - 机加工区 */}
        <rect x="570" y="150" width="80" height="40" fill="#c7d2fe" stroke="#6366f1" strokeWidth="1" rx="2" />
        <rect x="680" y="150" width="80" height="40" fill="#c7d2fe" stroke="#6366f1" strokeWidth="1" rx="2" />
        <rect x="790" y="150" width="80" height="40" fill="#c7d2fe" stroke="#6366f1" strokeWidth="1" rx="2" />
        <rect x="570" y="220" width="300" height="30" fill="#c7d2fe" stroke="#6366f1" strokeWidth="1" rx="2" />

        {/* 设备示意 - 卷板区 */}
        <rect x="150" y="420" width="120" height="50" fill="#ddd6fe" stroke="#8b5cf6" strokeWidth="1" rx="2" />
        <rect x="350" y="420" width="120" height="50" fill="#ddd6fe" stroke="#8b5cf6" strokeWidth="1" rx="2" />
        <rect x="550" y="420" width="120" height="50" fill="#ddd6fe" stroke="#8b5cf6" strokeWidth="1" rx="2" />
        <rect x="750" y="420" width="120" height="50" fill="#ddd6fe" stroke="#8b5cf6" strokeWidth="1" rx="2" />

        {/* 起重设备 */}
        <line x1="275" y1="80" x2="275" y2="290" stroke="#475569" strokeWidth="3" />
        <line x1="725" y1="80" x2="725" y2="290" stroke="#475569" strokeWidth="3" />
        <line x1="250" y1="340" x2="250" y2="530" stroke="#475569" strokeWidth="3" />
        <line x1="500" y1="340" x2="500" y2="530" stroke="#475569" strokeWidth="3" />
        <line x1="750" y1="340" x2="750" y2="530" stroke="#475569" strokeWidth="3" />

        {/* 图例 */}
        <rect x="800" y="520" width="150" height="30" fill="none" stroke="#64748b" strokeWidth="1" rx="2" />
        <text x="875" y="540" textAnchor="middle" fill="#334155" fontSize="12">
          核容分厂设备布局
        </text>
      </svg>
    </div>
  )
}

// 集箱分厂布局组件
function BoxFactoryLayout() {
  return (
    <div className="absolute inset-0 p-4">
      <svg width="100%" height="100%" viewBox="0 0 1000 600" className="border border-gray-200 rounded-md bg-gray-50">
        {/* 厂房外墙 */}
        <rect x="50" y="50" width="900" height="500" fill="#f8fafc" stroke="#94a3b8" strokeWidth="3" />

        {/* 主要区域分隔 */}
        <line x1="500" y1="50" x2="500" y2="550" stroke="#cbd5e1" strokeWidth="2" strokeDasharray="5,5" />
        <line x1="50" y1="300" x2="950" y2="300" stroke="#cbd5e1" strokeWidth="2" strokeDasharray="5,5" />

        {/* 左上区域 - 焊接区 */}
        <rect x="100" y="100" width="350" height="150" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" rx="5" />
        <text x="275" y="130" textAnchor="middle" fill="#334155" fontSize="16" fontWeight="bold">
          焊接区
        </text>

        {/* 右上区域 - 环缝焊接区 */}
        <rect x="550" y="100" width="350" height="150" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" rx="5" />
        <text x="725" y="130" textAnchor="middle" fill="#334155" fontSize="16" fontWeight="bold">
          环缝焊接区
        </text>

        {/* 左下区域 - 钻孔区 */}
        <rect x="100" y="350" width="350" height="150" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" rx="5" />
        <text x="275" y="380" textAnchor="middle" fill="#334155" fontSize="16" fontWeight="bold">
          钻孔区
        </text>

        {/* 右下区域 - 起重区 */}
        <rect x="550" y="350" width="350" height="150" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" rx="5" />
        <text x="725" y="380" textAnchor="middle" fill="#334155" fontSize="16" fontWeight="bold">
          起重区
        </text>

        {/* 通道 */}
        <rect x="50" y="275" width="900" height="50" fill="#f1f5f9" stroke="#94a3b8" strokeWidth="1" />
        <rect x="475" y="50" width="50" height="500" fill="#f1f5f9" stroke="#94a3b8" strokeWidth="1" />

        {/* 设备示意 - 焊接区 */}
        <rect x="120" y="150" width="60" height="30" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="1" rx="2" />
        <rect x="200" y="150" width="60" height="30" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="1" rx="2" />
        <rect x="280" y="150" width="60" height="30" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="1" rx="2" />
        <rect x="120" y="200" width="60" height="30" fill="#bfdbfe" stroke="#3b82f6" strokeWidth="1" rx="2" />

        {/* 设备示意 - 环缝焊接区 */}
        <rect x="600" y="150" width="100" height="40" fill="#c7d2fe" stroke="#6366f1" strokeWidth="1" rx="2" />
        <rect x="750" y="150" width="100" height="40" fill="#c7d2fe" stroke="#6366f1" strokeWidth="1" rx="2" />
        <rect x="600" y="210" width="250" height="30" fill="#c7d2fe" stroke="#6366f1" strokeWidth="1" rx="2" />

        {/* 设备示意 - 钻孔区 */}
        <rect x="150" y="420" width="70" height="40" fill="#ddd6fe" stroke="#8b5cf6" strokeWidth="1" rx="2" />
        <rect x="250" y="420" width="70" height="40" fill="#ddd6fe" stroke="#8b5cf6" strokeWidth="1" rx="2" />
        <rect x="350" y="420" width="70" height="40" fill="#ddd6fe" stroke="#8b5cf6" strokeWidth="1" rx="2" />

        {/* 设备示意 - 起重区 */}
        <rect x="600" y="400" width="80" height="80" fill="#fae8ff" stroke="#d946ef" strokeWidth="1" rx="2" />
        <rect x="750" y="400" width="80" height="80" fill="#fae8ff" stroke="#d946ef" strokeWidth="1" rx="2" />

        {/* 起重设备 */}
        <line x1="275" y1="80" x2="275" y2="270" stroke="#475569" strokeWidth="3" />
        <line x1="725" y1="80" x2="725" y2="270" stroke="#475569" strokeWidth="3" />
        <line x1="275" y1="330" x2="275" y2="520" stroke="#475569" strokeWidth="3" />
        <line x1="725" y1="330" x2="725" y2="520" stroke="#475569" strokeWidth="3" />

        {/* 图例 */}
        <rect x="800" y="520" width="150" height="30" fill="none" stroke="#64748b" strokeWidth="1" rx="2" />
        <text x="875" y="540" textAnchor="middle" fill="#334155" fontSize="12">
          集箱分厂设备布局
        </text>
      </svg>
    </div>
  )
}
