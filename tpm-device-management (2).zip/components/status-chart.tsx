"use client"

import { useEffect, useRef } from "react"
import type { Device } from "@/lib/types"

interface StatusChartProps {
  devices: Device[]
}

export default function StatusChart({ devices }: StatusChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    const ctx = canvasRef.current.getContext("2d")
    if (!ctx) return

    // 计算状态统计
    const statusCounts = {
      normal: devices.filter((d) => d.status === "正常").length,
      maintenance: devices.filter((d) => d.status === "维修中").length,
      disabled: devices.filter((d) => d.status === "停用").length,
    }

    // 计算部门统计
    const departmentCounts: Record<string, number> = {}
    devices.forEach((device) => {
      if (!departmentCounts[device.department]) {
        departmentCounts[device.department] = 0
      }
      departmentCounts[device.department]++
    })

    // 计算分类统计
    const categoryCounts: Record<string, number> = {}
    devices.forEach((device) => {
      if (!categoryCounts[device.category]) {
        categoryCounts[device.category] = 0
      }
      categoryCounts[device.category]++
    })

    // 绘制饼图
    const centerX = canvasRef.current.width / 2
    const centerY = canvasRef.current.height / 2
    const radius = Math.min(centerX, centerY) - 10

    const total = statusCounts.normal + statusCounts.maintenance + statusCounts.disabled
    let startAngle = 0

    // 绘制状态分布
    if (total > 0) {
      // 正常设备
      const normalAngle = (statusCounts.normal / total) * 2 * Math.PI
      ctx.fillStyle = "#22c55e" // 绿色
      ctx.beginPath()
      ctx.moveTo(centerX, centerY)
      ctx.arc(centerX, centerY, radius, startAngle, startAngle + normalAngle)
      ctx.closePath()
      ctx.fill()
      startAngle += normalAngle

      // 维修中设备
      const maintenanceAngle = (statusCounts.maintenance / total) * 2 * Math.PI
      ctx.fillStyle = "#eab308" // 黄色
      ctx.beginPath()
      ctx.moveTo(centerX, centerY)
      ctx.arc(centerX, centerY, radius, startAngle, startAngle + maintenanceAngle)
      ctx.closePath()
      ctx.fill()
      startAngle += maintenanceAngle

      // 停用设备
      const disabledAngle = (statusCounts.disabled / total) * 2 * Math.PI
      ctx.fillStyle = "#ef4444" // 红色
      ctx.beginPath()
      ctx.moveTo(centerX, centerY)
      ctx.arc(centerX, centerY, radius, startAngle, startAngle + disabledAngle)
      ctx.closePath()
      ctx.fill()
    }

    // 绘制图例
    ctx.fillStyle = "#000000"
    ctx.font = "14px Arial"

    // 正常设备图例
    ctx.fillStyle = "#22c55e"
    ctx.fillRect(20, 20, 20, 20)
    ctx.fillStyle = "#000000"
    ctx.fillText(`正常: ${statusCounts.normal}`, 50, 35)

    // 维修中设备图例
    ctx.fillStyle = "#eab308"
    ctx.fillRect(20, 50, 20, 20)
    ctx.fillStyle = "#000000"
    ctx.fillText(`维修中: ${statusCounts.maintenance}`, 50, 65)

    // 停用设备图例
    ctx.fillStyle = "#ef4444"
    ctx.fillRect(20, 80, 20, 20)
    ctx.fillStyle = "#000000"
    ctx.fillText(`停用: ${statusCounts.disabled}`, 50, 95)
  }, [devices])

  return (
    <div className="flex flex-col items-center">
      <canvas ref={canvasRef} width={400} height={300} />
      <p className="text-center text-sm text-gray-500 mt-4">设备状态分布图</p>
    </div>
  )
}
