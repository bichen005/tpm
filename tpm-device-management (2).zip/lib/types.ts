export interface Device {
  id: string
  name: string
  category: string
  assetNumber: string
  model: string
  totalPower: string
  department: string
  responsiblePerson: string
  status: string
  manufacturer: string
  serialNumber: string
  productionDate: string
  acceptanceDate: string
  installationLocation: string
  deviceGrade: string
  relatedDevices?: RelatedDevice[]
}

export interface RelatedDevice {
  deviceId: string
  relationType: string
}

export type RelationType = "配套设备" | "备用设备" | "替代设备" | "附属设备" | "上游设备" | "下游设备"
