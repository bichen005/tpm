"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PlusCircle, Search } from "lucide-react"
import DeviceTable from "@/components/device-table"
import DepartmentStatsCard from "@/components/department-stats-card"
import { useRouter } from "next/navigation"
import { deviceData } from "@/lib/data"

export default function DevicesPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [departmentFilter, setDepartmentFilter] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("")
  const [activeFilters, setActiveFilters] = useState({
    department: "",
    category: "",
  })
  // 分页相关状态
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10

  // 处理统计卡片的筛选变化
  const handleFilterChange = (department: string, category?: string) => {
    setDepartmentFilter(department)
    setCategoryFilter(category || "")
    setActiveFilters({
      department,
      category: category || "",
    })
    setCurrentPage(1) // 重置为第一页
  }

  // 处理部门筛选变化
  const handleDepartmentChange = (value: string) => {
    setDepartmentFilter(value)
    setActiveFilters((prev) => ({
      ...prev,
      department: value,
    }))
    setCurrentPage(1) // 重置为第一页
  }

  // 处理分类筛选变化
  const handleCategoryChange = (value: string) => {
    setCategoryFilter(value)
    setActiveFilters((prev) => ({
      ...prev,
      category: value,
    }))
    setCurrentPage(1) // 重置为第一页
  }

  // 处理搜索变化
  const handleSearchChange = (value: string) => {
    setSearchQuery(value)
    setCurrentPage(1) // 重置为第一页
  }

  // 过滤设备
  const filteredDevices = deviceData.filter((device) => {
    const matchesSearch =
      device.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      device.assetNumber.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesDepartment = departmentFilter === "" || device.department === departmentFilter
    const matchesCategory = categoryFilter === "" || device.category === categoryFilter
    return matchesSearch && matchesDepartment && matchesCategory
  })

  // 计算分页
  const totalPages = Math.ceil(filteredDevices.length / itemsPerPage)
  const paginatedDevices = filteredDevices.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold tracking-tight text-theme-700">设备管理</h2>
        <Button onClick={() => router.push("/devices/new")} className="bg-theme-700 hover:bg-theme-800">
          <PlusCircle className="mr-2 h-4 w-4" />
          新增设备
        </Button>
      </div>

      {/* 分厂设备统计卡片 - 调换了核容分厂和集箱分厂的位置 */}
      <div className="grid gap-4 md:grid-cols-3">
        <DepartmentStatsCard
          department="管子分厂"
          devices={deviceData}
          onFilterChange={handleFilterChange}
          activeFilters={activeFilters}
        />
        <DepartmentStatsCard
          department="核容分厂"
          devices={deviceData}
          onFilterChange={handleFilterChange}
          activeFilters={activeFilters}
        />
        <DepartmentStatsCard
          department="集箱分厂"
          devices={deviceData}
          onFilterChange={handleFilterChange}
          activeFilters={activeFilters}
        />
      </div>

      {/* 筛选控件 */}
      <div className="grid gap-4 md:grid-cols-3">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="搜索设备名称或固定资产编号..."
            className="pl-8 border-theme-200 focus-visible:ring-theme-500"
            value={searchQuery}
            onChange={(e) => handleSearchChange(e.target.value)}
          />
        </div>
        <Select value={departmentFilter} onValueChange={handleDepartmentChange}>
          <SelectTrigger className="border-theme-200 focus:ring-theme-500">
            <SelectValue placeholder="使用单位" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部单位</SelectItem>
            <SelectItem value="管子分厂">管子分厂</SelectItem>
            <SelectItem value="集箱分厂">集箱分厂</SelectItem>
            <SelectItem value="核容分厂">核容分厂</SelectItem>
          </SelectContent>
        </Select>
        <Select value={categoryFilter} onValueChange={handleCategoryChange}>
          <SelectTrigger className="border-theme-200 focus:ring-theme-500">
            <SelectValue placeholder="设备分类" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部分类</SelectItem>
            <SelectItem value="焊接设备">焊接设备</SelectItem>
            <SelectItem value="起重设备">起重设备</SelectItem>
            <SelectItem value="机加设备">机加设备</SelectItem>
            <SelectItem value="切割设备">切割设备</SelectItem>
            <SelectItem value="热处理设备">热处理设备</SelectItem>
            <SelectItem value="弯管机">弯管机</SelectItem>
            <SelectItem value="卷板机">卷板机</SelectItem>
            <SelectItem value="生产线">生产线</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <DeviceTable devices={paginatedDevices} />

      {/* 分页控件 */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-500">
            显示 {filteredDevices.length} 条结果中的 {(currentPage - 1) * itemsPerPage + 1} -{" "}
            {Math.min(currentPage * itemsPerPage, filteredDevices.length)} 条
          </div>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="border-theme-200 hover:bg-theme-50"
            >
              上一页
            </Button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
              <Button
                key={page}
                variant={page === currentPage ? "default" : "outline"}
                size="sm"
                onClick={() => setCurrentPage(page)}
                className={
                  page === currentPage ? "bg-theme-700 hover:bg-theme-800" : "border-theme-200 hover:bg-theme-50"
                }
              >
                {page}
              </Button>
            ))}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="border-theme-200 hover:bg-theme-50"
            >
              下一页
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
