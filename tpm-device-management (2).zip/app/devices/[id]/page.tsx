"use client"

import { useEffect, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Save } from "lucide-react"
import DeviceForm from "@/components/device-form"
import RelatedDevicesForm from "@/components/related-devices-form"
import { deviceData } from "@/lib/data"
import type { Device } from "@/lib/types"

export default function DeviceDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const viewMode = searchParams.get("mode") === "view"
  const [device, setDevice] = useState<Device | null>(null)
  const [loading, setLoading] = useState(true)
  const isNewDevice = params.id === "new"

  useEffect(() => {
    if (isNewDevice) {
      setDevice({
        id: "new",
        name: "",
        category: "",
        assetNumber: "",
        model: "",
        totalPower: "",
        department: "",
        responsiblePerson: "",
        status: "正常",
        manufacturer: "",
        serialNumber: "",
        productionDate: "",
        acceptanceDate: "",
        installationLocation: "",
        deviceGrade: "",
        relatedDevices: [],
      })
      setLoading(false)
    } else {
      // 在实际应用中，这里会从API获取设备详情
      const foundDevice = deviceData.find((d) => d.id === params.id)
      if (foundDevice) {
        setDevice(foundDevice)
      }
      setLoading(false)
    }
  }, [params.id, isNewDevice])

  const handleSave = (updatedDevice: Device) => {
    // 在实际应用中，这里会调用API保存设备信息
    console.log("保存设备信息:", updatedDevice)
    router.push("/devices")
  }

  if (loading) {
    return <div className="flex items-center justify-center h-full">加载中...</div>
  }

  if (!device && !isNewDevice) {
    return <div className="flex items-center justify-center h-full">未找到设备</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <Button variant="ghost" size="icon" onClick={() => router.push("/devices")} className="hover:bg-theme-100">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h2 className="text-2xl font-bold tracking-tight ml-2 text-theme-700">
            {isNewDevice ? "新增设备" : viewMode ? `设备详情: ${device?.name}` : `编辑设备: ${device?.name}`}
          </h2>
        </div>
        {!viewMode && (
          <Button onClick={() => device && handleSave(device)} className="bg-theme-700 hover:bg-theme-800">
            <Save className="mr-2 h-4 w-4" />
            保存
          </Button>
        )}
      </div>

      <Card>
        <CardContent className="p-6">
          <Tabs defaultValue="basic">
            <TabsList className="mb-6 bg-theme-100">
              <TabsTrigger value="basic" className="data-[state=active]:bg-theme-700 data-[state=active]:text-white">
                基本信息
              </TabsTrigger>
              <TabsTrigger value="detail" className="data-[state=active]:bg-theme-700 data-[state=active]:text-white">
                详细信息
              </TabsTrigger>
              <TabsTrigger value="related" className="data-[state=active]:bg-theme-700 data-[state=active]:text-white">
                关联设备
              </TabsTrigger>
            </TabsList>
            {device && (
              <>
                <TabsContent value="basic">
                  <DeviceForm
                    device={device}
                    onChange={setDevice}
                    fields={[
                      "name",
                      "category",
                      "assetNumber",
                      "model",
                      "totalPower",
                      "department",
                      "responsiblePerson",
                      "status",
                    ]}
                    readOnly={viewMode}
                  />
                </TabsContent>
                <TabsContent value="detail">
                  <DeviceForm
                    device={device}
                    onChange={setDevice}
                    fields={[
                      "manufacturer",
                      "serialNumber",
                      "productionDate",
                      "acceptanceDate",
                      "installationLocation",
                      "deviceGrade",
                    ]}
                    readOnly={viewMode}
                  />
                </TabsContent>
                <TabsContent value="related">
                  <RelatedDevicesForm device={device} onChange={setDevice} readOnly={viewMode} />
                </TabsContent>
              </>
            )}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
