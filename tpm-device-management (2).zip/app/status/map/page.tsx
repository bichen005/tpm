"use client"
import { useEffect, useState, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Maximize, Minimize, RefreshCw } from "lucide-react"
import { deviceData } from "@/lib/data"
import FactoryStatusCard from "@/components/factory-status-card"
import FactoryMap from "@/components/factory-map"

export default function StatusMapPage() {
  const [refreshTime, setRefreshTime] = useState<Date>(new Date())
  const [isFullscreen, setIsFullscreen] = useState(false)
  const pageRef = useRef<HTMLDivElement>(null)

  // 按部门过滤设备
  const getDevicesByDepartment = (department: string) => {
    return deviceData.filter((device) => device.department === department)
  }

  // 各分厂设备数据
  const pipeFactoryDevices = getDevicesByDepartment("管子分厂")
  const nuclearFactoryDevices = getDevicesByDepartment("核容分厂")
  const boxFactoryDevices = getDevicesByDepartment("集箱分厂")

  // 每5秒刷新一次数据
  useEffect(() => {
    const interval = setInterval(() => {
      setRefreshTime(new Date())
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  // 处理全屏切换
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      // 进入全屏
      if (pageRef.current?.requestFullscreen) {
        pageRef.current
          .requestFullscreen()
          .then(() => {
            setIsFullscreen(true)
          })
          .catch((err) => {
            console.error(`全屏错误: ${err.message}`)
          })
      }
    } else {
      // 退出全屏
      if (document.exitFullscreen) {
        document
          .exitFullscreen()
          .then(() => {
            setIsFullscreen(false)
          })
          .catch((err) => {
            console.error(`退出全屏错误: ${err.message}`)
          })
      }
    }
  }

  // 监听全屏状态变化
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener("fullscreenchange", handleFullscreenChange)
    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange)
    }
  }, [])

  return (
    <div ref={pageRef} className={`space-y-4 ${isFullscreen ? "bg-gray-100 p-6 min-h-screen" : ""}`}>
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold tracking-tight text-theme-700">设备状态地图</h2>
        <div className="flex items-center gap-2">
          <div className="text-sm text-gray-500 mr-2">最后更新: {refreshTime.toLocaleTimeString()}</div>
          <Button
            variant="outline"
            size="icon"
            onClick={toggleFullscreen}
            className="border-theme-200 hover:bg-theme-50"
          >
            {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setRefreshTime(new Date())}
            className="border-theme-200 hover:bg-theme-50"
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* 分厂设备运行状态统计卡片 */}
      <div className="grid gap-3 md:grid-cols-3">
        <FactoryStatusCard
          title="管子分厂"
          devices={pipeFactoryDevices}
          collectionRate="32条/秒"
          coreStats={[
            { label: "焊接时长", value: "3204 h" },
            { label: "蛇形管", value: "3453盘" },
            { label: "膜式壁", value: "1245 h" },
          ]}
          refreshTime={refreshTime}
        />
        <FactoryStatusCard
          title="核容分厂"
          devices={nuclearFactoryDevices}
          collectionRate="28条/秒"
          coreStats={[
            { label: "焊接时长", value: "1204 h" },
            { label: "卷板", value: "150 h" },
          ]}
          refreshTime={refreshTime}
        />
        <FactoryStatusCard
          title="集箱分厂"
          devices={boxFactoryDevices}
          collectionRate="25条/秒"
          coreStats={[
            { label: "焊接时长", value: "563 h" },
            { label: "钻孔", value: "234 h" },
          ]}
          refreshTime={refreshTime}
        />
      </div>

      {/* 品字型分厂设备状态地图 */}
      <div className="grid grid-cols-1 gap-4">
        {/* 上方大区域 - 管子分厂 */}
        <Card className="border-theme-200">
          <CardHeader className="bg-theme-50 py-2 px-4">
            <CardTitle className="text-theme-700">管子分厂设备状态地图</CardTitle>
          </CardHeader>
          <CardContent className="p-0 h-[400px]">
            <FactoryMap
              type="pipe"
              devices={pipeFactoryDevices}
              equipmentList={[
                "CO2气体保护焊",
                "氩弧焊机",
                "直流焊机",
                "交流电焊机",
                "螺柱焊机",
                "100米蛇形管自动线",
                "70米蛇形管自动线",
                "4头膜式壁生产线",
                "8头膜式壁生产线",
                "20头膜式壁生产线",
                "液压弯管机",
                "桥式行车",
                "半龙门吊",
              ]}
              refreshTime={refreshTime}
            />
          </CardContent>
        </Card>

        {/* 下方两个区域 */}
        <div className="grid grid-cols-2 gap-4">
          {/* 左下 - 核容分厂 */}
          <Card className="border-theme-200">
            <CardHeader className="bg-theme-50 py-2 px-4">
              <CardTitle className="text-theme-700">核容分厂设备状态地图</CardTitle>
            </CardHeader>
            <CardContent className="p-0 h-[350px]">
              <FactoryMap
                type="nuclear"
                devices={nuclearFactoryDevices}
                equipmentList={[
                  "直流焊机",
                  "氩弧焊机",
                  "CO2气体保护焊",
                  "马鞍埋弧焊机",
                  "环缝自动焊机",
                  "桥式行车",
                  "三辊卷板机",
                  "摇臂钻床",
                ]}
                refreshTime={refreshTime}
              />
            </CardContent>
          </Card>

          {/* 右下 - 集箱分厂 */}
          <Card className="border-theme-200">
            <CardHeader className="bg-theme-50 py-2 px-4">
              <CardTitle className="text-theme-700">集箱分厂设备状态地图</CardTitle>
            </CardHeader>
            <CardContent className="p-0 h-[300px]">
              <FactoryMap
                type="box"
                devices={boxFactoryDevices}
                equipmentList={[
                  "CO2气体保护焊",
                  "氩弧焊机",
                  "直流焊机",
                  "螺柱焊机",
                  "窄间隙环缝焊工作站",
                  "桥式行车",
                  "半龙门吊",
                  "摇臂钻床",
                ]}
                refreshTime={refreshTime}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
