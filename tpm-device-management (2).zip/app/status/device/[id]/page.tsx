"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft } from "lucide-react"
import { deviceData } from "@/lib/data"
import type { Device } from "@/lib/types"
import { cn } from "@/lib/utils"
import { format, subDays } from "date-fns"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
// 在 import 部分添加 DatePickerWithRange 组件的导入
import { DatePickerWithRange } from "@/components/date-range-picker"
import type { DateRange } from "react-day-picker"

// 运行状态指示器组件
function RunningStatusIndicator({ status }: { status: "running" | "standby" | "off" }) {
  const [blink, setBlink] = useState(true)

  // 只有运行状态需要闪烁效果
  useEffect(() => {
    if (status === "running") {
      const interval = setInterval(() => {
        setBlink((prev) => !prev)
      }, 1000)
      return () => clearInterval(interval)
    }
  }, [status])

  const getStatusColor = () => {
    switch (status) {
      case "running":
        return blink ? "bg-green-500 shadow-sm shadow-green-200" : "bg-green-400"
      case "standby":
        return "bg-yellow-400"
      case "off":
        return "bg-gray-400"
      default:
        return "bg-gray-400"
    }
  }

  const getStatusText = () => {
    switch (status) {
      case "running":
        return "运行"
      case "standby":
        return "待机"
      case "off":
        return "关机"
      default:
        return "未知"
    }
  }

  return (
    <div className="flex items-center">
      <div
        className={cn("w-3 h-3 rounded-full mr-2 transition-all duration-300", getStatusColor())}
        aria-hidden="true"
      />
      <span>{getStatusText()}</span>
    </div>
  )
}

// 生成模拟的图表数据
function generateChartData() {
  const today = new Date()
  const users = ["张三", "李四", "王五", "赵六", "钱七", "孙八", "周九", "吴十"]

  return Array.from({ length: 15 }, (_, index) => {
    const date = subDays(today, 14 - index)
    const dateStr = format(date, "MM-dd")
    const user = users[Math.floor(Math.random() * users.length)]
    const runningHours = Number.parseFloat((Math.random() * 12).toFixed(1))
    const standbyHours = Number.parseFloat((Math.random() * 8).toFixed(1))

    return {
      date: dateStr,
      user,
      runningHours,
      standbyHours,
    }
  })
}

export default function DeviceRunningStatusDetailPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const [device, setDevice] = useState<Device | null>(null)
  const [loading, setLoading] = useState(true)

  // 模拟的运行数据
  const [runningData, setRunningData] = useState({
    last15DaysHours: 0,
    currentUser: "",
    totalRunningHours: 0,
    runningStatus: "running" as "running" | "standby" | "off",
  })

  // 在 DeviceRunningStatusDetailPage 函数内，useState 部分添加日期范围状态
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: subDays(new Date(), 14),
    to: new Date(),
  })

  // 图表数据
  const [chartData, setChartData] = useState<any[]>([])

  // 在 chartData 状态下方添加过滤后的图表数据状态
  const [filteredChartData, setFilteredChartData] = useState<any[]>([])

  useEffect(() => {
    // 在实际应用中，这里会从API获取设备详情
    const foundDevice = deviceData.find((d) => d.id === params.id)
    if (foundDevice) {
      setDevice(foundDevice)

      // 生成模拟的运行数据
      const last15DaysHours = Number.parseFloat((Math.random() * 360).toFixed(1))
      const users = ["张三", "李四", "王五", "赵六", "钱七", "孙八", "周九", "吴十"]
      const currentUser = users[Math.floor(Math.random() * users.length)]
      const totalRunningHours = Number.parseFloat((Math.random() * 5000).toFixed(1))
      const statuses: Array<"running" | "standby" | "off"> = ["running", "standby", "off"]
      const runningStatus = statuses[Math.floor(Math.random() * statuses.length)]

      setRunningData({
        last15DaysHours,
        currentUser,
        totalRunningHours,
        runningStatus,
      })

      // 生成图表数据
      const initialChartData = generateChartData()
      setChartData(initialChartData)
      setFilteredChartData(initialChartData)
    }
    setLoading(false)
  }, [params.id])

  // 在 useEffect 之后，添加日期过滤逻辑
  useEffect(() => {
    if (!chartData.length) return

    if (!dateRange?.from) {
      setFilteredChartData(chartData)
      return
    }

    const fromDate = new Date(dateRange.from)
    fromDate.setHours(0, 0, 0, 0)

    const toDate = dateRange.to ? new Date(dateRange.to) : fromDate
    toDate.setHours(23, 59, 59, 999)

    // 计算日期范围内的数据
    const today = new Date()
    const filtered = chartData.filter((_, index) => {
      const itemDate = subDays(today, 14 - index)
      return itemDate >= fromDate && itemDate <= toDate
    })

    setFilteredChartData(filtered)
  }, [chartData, dateRange])

  // 添加日期范围变更处理函数
  const handleDateRangeChange = (newDateRange: DateRange | undefined) => {
    setDateRange(newDateRange)
  }

  if (loading) {
    return <div className="flex items-center justify-center h-full">加载中...</div>
  }

  if (!device) {
    return <div className="flex items-center justify-center h-full">未找到设备</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center">
        <Button variant="ghost" size="icon" onClick={() => router.push("/status")} className="hover:bg-theme-100">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h2 className="text-2xl font-bold tracking-tight ml-2 text-theme-700">设备运行状态详情: {device.name}</h2>
      </div>

      {/* 合并的设备信息卡片 */}
      <Card className="border-theme-200">
        <CardHeader className="bg-theme-50 py-2">
          <CardTitle className="text-theme-700 text-lg">设备信息</CardTitle>
        </CardHeader>
        <CardContent className="p-3">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-x-4 gap-y-2 text-sm">
            <div>
              <p className="text-xs text-gray-500">设备名称</p>
              <p className="font-medium truncate">{device.name}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">设备分类</p>
              <p className="font-medium truncate">{device.category}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">固定资产编号</p>
              <p className="font-medium truncate">{device.assetNumber}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">使用单位</p>
              <p className="font-medium truncate">{device.department}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">型号/规格</p>
              <p className="font-medium truncate">{device.model}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">当前使用人</p>
              <p className="font-medium truncate">{runningData.currentUser}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">近15日运行时长</p>
              <p className="font-medium truncate">{runningData.last15DaysHours} 小时</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">总运行时长</p>
              <p className="font-medium truncate">{runningData.totalRunningHours} 小时</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">当前运行状态</p>
              <div className="font-medium">
                <RunningStatusIndicator status={runningData.runningStatus} />
              </div>
            </div>
            <div>
              <p className="text-xs text-gray-500">设备状态</p>
              <p className="font-medium truncate">{device.status}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">责任人</p>
              <p className="font-medium truncate">{device.responsiblePerson}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 运行趋势图表 */}
      <Card className="border-theme-200">
        <CardHeader className="bg-theme-50 py-2 flex flex-row justify-between items-center">
          <CardTitle className="text-theme-700 text-lg">运行趋势</CardTitle>
          <div className="flex items-center">
            <DatePickerWithRange className="w-[300px]" value={dateRange} onChange={handleDateRangeChange} />
          </div>
        </CardHeader>
        <CardContent className="p-4">
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={filteredChartData}
                margin={{
                  top: 20,
                  right: 30,
                  left: 20,
                  bottom: 60,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="date"
                  height={60}
                  tick={(props) => {
                    const { x, y, payload } = props
                    const index = filteredChartData.findIndex((item) => item.date === payload.value)
                    const user = index >= 0 ? filteredChartData[index].user : ""

                    return (
                      <g transform={`translate(${x},${y})`}>
                        <text x={0} y={0} dy={16} textAnchor="middle" fill="#666" fontSize={12}>
                          {payload.value}
                        </text>
                        <text x={0} y={0} dy={32} textAnchor="middle" fill="#666" fontSize={10}>
                          {user}
                        </text>
                      </g>
                    )
                  }}
                />
                <YAxis label={{ value: "时长(小时)", angle: -90, position: "insideLeft" }} />
                <Tooltip
                  formatter={(value, name) => {
                    return [`${value} 小时`, name === "runningHours" ? "运行时长" : "待机时长"]
                  }}
                  labelFormatter={(label) => {
                    const index = filteredChartData.findIndex((item) => item.date === label)
                    const user = index >= 0 ? filteredChartData[index].user : ""
                    return `${label} (${user})`
                  }}
                />
                <Legend />
                <Bar dataKey="runningHours" stackId="a" fill="#22c55e" name="运行时长" />
                <Bar dataKey="standbyHours" stackId="a" fill="#eab308" name="待机时长" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* 为更多内容预留空间 */}
      <Card className="border-theme-200">
        <CardHeader className="bg-theme-50 py-2">
          <CardTitle className="text-theme-700 text-lg">运行详情</CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <div className="h-96 flex items-center justify-center bg-gray-100 rounded-md">
            <p className="text-gray-500">此处可以添加更多详细的运行数据和分析</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
