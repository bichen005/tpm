"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Search, Clock, Activity, User } from "lucide-react"
import { deviceData } from "@/lib/data"
import DepartmentStatsCard from "@/components/department-stats-card"
import DeviceRunningStatusList from "@/components/device-running-status-list"

export default function StatusPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [departmentFilter, setDepartmentFilter] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("")
  const [runningHoursRange, setRunningHoursRange] = useState<[number, number]>([0, 360])
  const [runningStatusFilter, setRunningStatusFilter] = useState("")
  const [userFilter, setUserFilter] = useState("")
  const [activeFilters, setActiveFilters] = useState({
    department: "",
    category: "",
  })

  // 处理统计卡片的筛选变化
  const handleFilterChange = (department: string, category?: string) => {
    setDepartmentFilter(department)
    setCategoryFilter(category || "")
    setActiveFilters({
      department,
      category: category || "",
    })
  }

  // 处理部门筛选变化
  const handleDepartmentChange = (value: string) => {
    setDepartmentFilter(value)
    setActiveFilters((prev) => ({
      ...prev,
      department: value,
    }))
  }

  // 处理分类筛选变化
  const handleCategoryChange = (value: string) => {
    setCategoryFilter(value)
    setActiveFilters((prev) => ({
      ...prev,
      category: value,
    }))
  }

  // 处理搜索变化
  const handleSearchChange = (value: string) => {
    setSearchQuery(value)
  }

  // 处理运行时长范围变化
  const handleRunningHoursChange = (value: number[]) => {
    setRunningHoursRange([value[0], value[1]])
  }

  // 处理运行状态筛选变化
  const handleRunningStatusChange = (value: string) => {
    setRunningStatusFilter(value)
  }

  // 处理使用人筛选变化
  const handleUserFilterChange = (value: string) => {
    setUserFilter(value)
  }

  // 过滤设备
  const filteredDevices = deviceData.filter((device) => {
    const matchesSearch =
      device.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      device.assetNumber.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesDepartment = departmentFilter === "" || device.department === departmentFilter
    const matchesCategory = categoryFilter === "" || device.category === categoryFilter
    return matchesSearch && matchesDepartment && matchesCategory
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold tracking-tight text-theme-700">设备状态</h2>
      </div>

      {/* 分厂设备统计卡片 */}
      <div className="grid gap-4 md:grid-cols-3">
        <DepartmentStatsCard
          department="管子分厂"
          devices={deviceData}
          onFilterChange={handleFilterChange}
          activeFilters={activeFilters}
        />
        <DepartmentStatsCard
          department="核容分厂"
          devices={deviceData}
          onFilterChange={handleFilterChange}
          activeFilters={activeFilters}
        />
        <DepartmentStatsCard
          department="集箱分厂"
          devices={deviceData}
          onFilterChange={handleFilterChange}
          activeFilters={activeFilters}
        />
      </div>

      {/* 基本筛选控件 */}
      <div className="grid gap-4 md:grid-cols-3">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="搜索设备名称或固定资产编号..."
            className="pl-8 border-theme-200 focus-visible:ring-theme-500"
            value={searchQuery}
            onChange={(e) => handleSearchChange(e.target.value)}
          />
        </div>
        <Select value={departmentFilter} onValueChange={handleDepartmentChange}>
          <SelectTrigger className="border-theme-200 focus:ring-theme-500">
            <SelectValue placeholder="使用单位" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部单位</SelectItem>
            <SelectItem value="管子分厂">管子分厂</SelectItem>
            <SelectItem value="集箱分厂">集箱分厂</SelectItem>
            <SelectItem value="核容分厂">核容分厂</SelectItem>
          </SelectContent>
        </Select>
        <Select value={categoryFilter} onValueChange={handleCategoryChange}>
          <SelectTrigger className="border-theme-200 focus:ring-theme-500">
            <SelectValue placeholder="设备分类" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部分类</SelectItem>
            <SelectItem value="焊接设备">焊接设备</SelectItem>
            <SelectItem value="起重设备">起重设备</SelectItem>
            <SelectItem value="机加设备">机加设备</SelectItem>
            <SelectItem value="切割设备">切割设备</SelectItem>
            <SelectItem value="热处理设备">热处理设备</SelectItem>
            <SelectItem value="弯管机">弯管机</SelectItem>
            <SelectItem value="卷板机">卷板机</SelectItem>
            <SelectItem value="生产线">生产线</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* 高级筛选控件 */}
      <div className="grid gap-4 md:grid-cols-3">
        <div className="space-y-2">
          <div className="flex items-center text-sm font-medium">
            <Clock className="mr-2 h-4 w-4 text-gray-500" />
            近15日运行时长: {runningHoursRange[0]}h - {runningHoursRange[1]}h
          </div>
          <Slider
            defaultValue={[0, 360]}
            min={0}
            max={360}
            step={10}
            value={runningHoursRange}
            onValueChange={handleRunningHoursChange}
            className="py-4"
          />
        </div>
        <div className="relative">
          <Activity className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Select value={runningStatusFilter} onValueChange={handleRunningStatusChange}>
            <SelectTrigger className="pl-8 border-theme-200 focus:ring-theme-500">
              <SelectValue placeholder="当前运行状态" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部状态</SelectItem>
              <SelectItem value="running">运行</SelectItem>
              <SelectItem value="standby">待机</SelectItem>
              <SelectItem value="off">关机</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="relative">
          <User className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            placeholder="搜索当前使用人..."
            className="pl-8 border-theme-200 focus-visible:ring-theme-500"
            value={userFilter}
            onChange={(e) => handleUserFilterChange(e.target.value)}
          />
        </div>
      </div>

      {/* 设备运行状态列表 */}
      <Card className="border-theme-200">
        <CardContent className="p-0">
          <DeviceRunningStatusList
            devices={filteredDevices}
            runningHoursRange={runningHoursRange}
            runningStatusFilter={runningStatusFilter}
            userFilter={userFilter}
          />
        </CardContent>
      </Card>
    </div>
  )
}
